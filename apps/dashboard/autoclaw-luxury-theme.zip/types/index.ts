export type DealerType = "dealer" | "private";

export type VehicleStatus = "listed" | "pending" | "sold" | "draft";

export type SyndicationChannel = "facebook" | "instagram" | "jiji" | "cars45";

export interface Vehicle {
  id: string;
  year: number;
  make: string;
  model: string;
  trim?: string;
  priceNaira: number;
  status: VehicleStatus;
  aiOptimized: boolean;
  syndicatedTo: SyndicationChannel[];
  imageQuery?: string;
}

export type AgentStatus = "active" | "processing" | "idle";

export interface AgentWorker {
  id: string;
  name: string;
  role: string;
  status: AgentStatus;
  queueDepth: number;
  throughputPerHour: number;
  errorRatePct: number;
  lastProcessed: string;
  workerPid: string;
  description: string;
}
