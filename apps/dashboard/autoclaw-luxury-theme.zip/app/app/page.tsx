import { OpsDashboard } from "@/components/ops/ops-dashboard";

export default function DashboardPage() {
  return <OpsDashboard />;
}
